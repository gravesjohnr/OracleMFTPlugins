define([], function() {
  'use strict';

  var PageModule = function PageModule() {
    PageModule.prototype.getTimeSeriesValues = function () {
      console.log("here.");
      return "test123.";
  }
    
    };

  return PageModule;
});
