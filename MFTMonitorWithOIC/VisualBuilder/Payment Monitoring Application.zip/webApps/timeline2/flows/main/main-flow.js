define([], function() {
  'use strict';

  var FlowModule = function FlowModule() {
    
    FlowModule.prototype.formatData = function(jsonObject) {
      var responseObject = [];
      console.log("object: %O", jsonObject);
      console.log("object: "+jsonObject.status);
      for(var i=0;i<jsonObject.body.items.length;i++){
        console.log("Item: ["+i+"]: "+jsonObject.body.items[i].id);
        console.log("Date before: "+jsonObject.body.items[i].creationDate);
        var d = new Date(jsonObject.body.items[i].creationDate);
        console.log("Data after: "+d.toISOString());
        responseObject.push({"id": jsonObject.body.items[i].businessID, "title": jsonObject.body.items[i].businessID, "start": d.toISOString(), "description": jsonObject.body.items[i].currentStepName});
      }
      console.log("response: %O", responseObject);
      return responseObject;
    }
    };

  return FlowModule;
});